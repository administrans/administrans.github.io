To create the tables that were on Dominique Unruh’s former website at
unruh.de, use the following command:

    makeunidef.pl $PATHTOUCS/data/*.ucf --nodata --nocomments --tabledir .

Then you can compile the generated .tex files.

The content of this directory is given as is. No support can be
obtained. You may tell me errors, I will thank you, but I may ignore
them.
